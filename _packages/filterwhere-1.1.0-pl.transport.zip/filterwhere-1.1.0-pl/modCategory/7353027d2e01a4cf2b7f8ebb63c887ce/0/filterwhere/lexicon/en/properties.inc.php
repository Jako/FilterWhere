<?php
$_lang['filterwhere.filtergetresourceswhere.emptyRedirect'] = 'ID of a resource, the user is redirected to, when the generated where clause is empty.';
$_lang['filterwhere.filtergetresourceswhere.fields'] = 'JSON encoded array of filter => resourcefield combinations.';
$_lang['filterwhere.filtergetresourceswhere.toPlaceholder'] = 'If set, the snippet result will be assigned to this placeholder instead of outputting it directly.';
$_lang['filterwhere.filtergetresourceswhere.where'] = 'JSON encoded xPDO where clause to filter the resources.';
$_lang['filterwhere.filtergetresourceswhere.varName'] = 'Name of the superglobal variable that is searched for the filter values.';
