<?php
/**
 * FilterWhere
 *
 * Copyright 2021-2025 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package filterwhere
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * Class FilterWhere
 */
class FilterWhere extends \TreehillStudio\FilterWhere\FilterWhere
{
}
