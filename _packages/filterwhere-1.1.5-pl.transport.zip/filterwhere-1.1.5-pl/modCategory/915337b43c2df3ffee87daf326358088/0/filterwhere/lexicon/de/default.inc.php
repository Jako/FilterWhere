<?php
/**
 * Default Lexicon Entries for FilterWhere
 *
 * @package filterwhere
 * @subpackage lexicon
 */
$_lang['filterwhere'] = 'FilterWhere';
