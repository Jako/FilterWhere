<?php
/**
 * Setting Lexicon Entries for FilterWhere
 *
 * @package filterwhere
 * @subpackage lexicon
 */
$_lang['setting_filterwhere.debug'] = 'Debug';
$_lang['setting_filterwhere.debug_desc'] = 'Log debug information in the MODX error log.';
