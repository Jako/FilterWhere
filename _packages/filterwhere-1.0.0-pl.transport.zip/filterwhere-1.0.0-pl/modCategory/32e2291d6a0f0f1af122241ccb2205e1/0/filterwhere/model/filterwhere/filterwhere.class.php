<?php
/**
 * FilterWhere
 *
 * Copyright 2021 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package filterwhere
 * @subpackage classfile
 */

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';

/**
 * Class FilterWhere
 */
class FilterWhere extends \TreehillStudio\FilterWhere\FilterWhere
{
}
